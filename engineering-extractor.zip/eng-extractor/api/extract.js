export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'ANTHROPIC_API_KEY is not set in environment variables.' });
  }

  const { base64Data, mediaType, isPdf, customPrompt } = req.body;

  if (!base64Data || !mediaType) {
    return res.status(400).json({ error: 'Missing file data.' });
  }

  let promptText = `You are an expert technical assistant for engineers. Extract ALL technical data, dimensions, tolerances, quantities, materials, and engineering values from this document with absolute precision.

STRICT RULES:
1. Group identical items — do NOT list them separately. Show total quantity (e.g. "Length 50mm - Qty: 4").
2. For every value, include the EXACT source text from the document (verbatim, like a snapshot).
3. Zero fluff — only concrete engineering values.

You MUST respond with ONLY a valid JSON array. No markdown, no backticks, no explanation. Format:
[
  {
    "parameter": "parameter name (e.g. Bolt length, Pipe OD, Tolerance)",
    "value": "value with unit (e.g. 50mm, 3/4 inch, ±0.05mm)",
    "qty": null or integer,
    "category": "one of: dimension | quantity | tolerance | material | pressure | temperature | weight | other",
    "source_snippet": "exact verbatim text from document where this was found"
  }
]`;

  if (customPrompt && customPrompt.trim() !== '') {
    promptText += `\n\nCRITICAL FOCUS: Extract data based EXCLUSIVELY on this request: "${customPrompt}".`;
  }

  const contentBlock = isPdf
    ? { type: 'document', source: { type: 'base64', media_type: mediaType, data: base64Data } }
    : { type: 'image', source: { type: 'base64', media_type: mediaType, data: base64Data } };

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 4096,
        messages: [{
          role: 'user',
          content: [contentBlock, { type: 'text', text: promptText }]
        }]
      })
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(500).json({ error: data.error?.message || 'Anthropic API error' });
    }

    const rawText = data.content.map(b => b.text || '').join('');
    const clean = rawText.replace(/```json|```/g, '').trim();

    let parsed;
    try {
      parsed = JSON.parse(clean);
    } catch (e) {
      return res.status(500).json({ error: 'Could not parse Claude response. The document may contain no extractable technical data.' });
    }

    return res.status(200).json(parsed);

  } catch (err) {
    return res.status(500).json({ error: err.message || 'Unknown server error' });
  }
}

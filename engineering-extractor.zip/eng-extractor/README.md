# Engineering Data Extractor

Upload engineering PDFs or images — Claude AI extracts all dimensions, tolerances, quantities, and materials instantly.

---

## 🚀 Deploy on Vercel (recommended — free)

### Step 1 — Get your Anthropic API Key
1. Go to https://console.anthropic.com
2. Sign up or log in
3. Click **API Keys** → **Create Key**
4. Copy the key (starts with `sk-ant-...`)

### Step 2 — Upload to GitHub
1. Go to https://github.com and create a new repository (name it anything)
2. Upload all these files by dragging them into the repo page
3. Click **Commit changes**

### Step 3 — Deploy on Vercel
1. Go to https://vercel.com and sign up with your GitHub account
2. Click **Add New Project** → select your GitHub repo
3. Click **Deploy** (it will fail — that's expected, we need the API key next)

### Step 4 — Add your API Key
1. In your Vercel project, go to **Settings** → **Environment Variables**
2. Add:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** `sk-ant-...` (your key from Step 1)
3. Click **Save**
4. Go to **Deployments** → click the 3 dots on your latest deployment → **Redeploy**

### ✅ Done!
Your website is now live at `https://your-project-name.vercel.app`

---

## 💻 Run Locally on Your Computer

### Requirements
- Node.js 18+ (download from https://nodejs.org)

### Steps
```bash
# 1. Install Vercel CLI
npm install -g vercel

# 2. Go into project folder
cd engineering-data-extractor

# 3. Create local environment file
echo "ANTHROPIC_API_KEY=sk-ant-YOUR_KEY_HERE" > .env.local

# 4. Run locally
vercel dev
```

Then open http://localhost:3000 in your browser.

---

## 📁 File Structure
```
/
├── public/
│   └── index.html     ← The full UI (frontend)
├── api/
│   └── extract.js     ← The backend (calls Claude API)
├── vercel.json        ← Vercel deployment config
├── package.json       ← Project metadata
└── README.md          ← This file
```

---

## How it works
1. User uploads a PDF or image
2. Browser sends file to `/api/extract` (your server)
3. Server adds your secret API key and calls Claude
4. Claude returns structured JSON data
5. UI displays results in a filterable table
